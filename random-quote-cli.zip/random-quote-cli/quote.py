import random

quotes = [
    "The only limit to our realization of tomorrow is our doubts of today. – F. D. Roosevelt",
    "Do one thing every day that scares you. – Eleanor Roosevelt",
    "Dream big and dare to fail. – Norman Vaughan",
    "What you get by achieving your goals is not as important as what you become by achieving your goals. – Zig Ziglar",
    "Believe you can and you're halfway there. – Theodore Roosevelt"
]

def show_random_quote():
    print("\n💬 " + random.choice(quotes) + "\n")

if __name__ == "__main__":
    show_random_quote()
