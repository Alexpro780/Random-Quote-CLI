# Random Quote CLI

A simple Python command-line tool that prints a random inspirational quote each time you run it.

## Features

- Displays a random quote from a predefined list
- Lightweight and fast
- Easy to extend with your own quotes

## Usage

```bash
python quote.py
```

## Example Output

> “The only limit to our realization of tomorrow is our doubts of today.” – F. D. Roosevelt

Enjoy and stay inspired!
